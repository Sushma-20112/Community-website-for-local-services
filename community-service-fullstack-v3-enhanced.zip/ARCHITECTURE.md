# 🏗️ CommunityHub Architecture Overview

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         COMMUNITYHUB SYSTEM v3.0                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────┐   ┌─────────────────────────────────┐
│        FRONTEND (React/TypeScript)     │   │   BACKEND (Express.js/Node)     │
├────────────────────────────────────────┤   ├─────────────────────────────────┤
│                                        │   │                                 │
│  Home Page                             │   │  Public Routes:                 │
│  ├─ Service Browse                     │   │  ├─ GET /api/health            │
│  ├─ Service Search                     │   │  ├─ GET /api/categories        │
│  └─ Request Submission                 │   │  ├─ GET /api/providers         │
│                                        │   │  └─ POST /api/requests         │
│  Admin Login (Enhanced)                │   │                                 │
│  ├─ Service Selector                   │   │  Protected Routes:             │
│  ├─ Demo Credentials Display           │   │  ├─ POST /api/admin/login      │
│  └─ Auto-fill Buttons                  │   │  ├─ GET /api/admin/requests    │
│                                        │   │  ├─ PATCH /api/admin/requests/:id
│  Service Dashboard (Generic)           │   │  └─ GET /api/admin/stats       │
│  ├─ Stats Cards                        │   │                                 │
│  ├─ Activity Charts                    │   │  Database:                     │
│  ├─ Request Table                      │   │  └─ db.json (JSON persistence) │
│  ├─ Status Filtering                   │   │     ├─ providers[]            │
│  └─ Real-time Updates                  │   │     ├─ requests[]             │
│                                        │   │     └─ admins[]               │
│  Super Admin Overview                  │   │                                 │
│  ├─ Global Statistics                  │   │  Middleware:                   │
│  ├─ Service Cards Grid                 │   │  └─ JWT Authentication         │
│  ├─ Comparison Table                   │   │                                 │
│  └─ Quick Navigation                   │   │  Security:                     │
│                                        │   │  ├─ CORS enabled              │
│  Routes:                               │   │  ├─ JWT tokens (8h expiry)    │
│  ├─ / (home)                           │   │  └─ Role-based access control │
│  ├─ /admin (login)                     │   │                                 │
│  ├─ /admin/dashboard/overview          │   │                                 │
│  ├─ /admin/dashboard/:category         │   │                                 │
│  └─ /admin/old (legacy)                │   │                                 │
│                                        │   │                                 │
└────────────────────────────────────────┘   └─────────────────────────────────┘
         ↓               ↑                               ↓          ↑
         └───────────── HTTP/REST ─────────────────────┘
            (Port 5173)                  (Port 5000)
                                      
```

---

## Data Flow Architecture

```
USER WORKFLOW:

1. CITIZEN (Submitting Request)
   ┌─────────────┐
   │  Home Page  │
   └──────┬──────┘
          │
          ├──→ Browse/Search Services
          │
          └──→ Fill Request Form
              ├─ Customer Name
              ├─ Phone
              ├─ Address
              └─ Details
              
              ↓
              
          ┌──────────────────┐
          │ Submit via API   │
          │ POST /requests   │
          └────────┬─────────┘
                   ↓
              ┌────────────┐
              │  Backend   │
              │  Validates │
              └────┬───────┘
                   ↓
              ┌────────────────┐
              │ Save to db.json│
              └────────┬───────┘
                       ↓
                  ✅ Success
                  
                  
2. SERVICE ADMIN (Viewing Dashboard)
   ┌──────────────┐
   │  Login Page  │
   └──────┬───────┘
          │
          ├──→ Enter Credentials
          │    (e.g., police/police123)
          │
          └──→ Click Sign In
              ↓
          ┌──────────────────┐
          │ POST /admin/login│
          └────────┬─────────┘
                   ↓
              ┌────────────────┐
              │ Verify & Issue │
              │ JWT Token      │
              └────────┬───────┘
                       ↓
              ┌────────────────┐
              │ Store Token    │
              │ (localStorage) │
              └────────┬───────┘
                       ↓
          ┌──────────────────────────┐
          │ Redirect to Dashboard    │
          │ /admin/dashboard/police  │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Dashboard Loads          │
          │ - Fetch requests (auth)  │
          │ - Fetch stats (auth)     │
          │ - Render UI              │
          │ - Start 5s auto-refresh  │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Display:                 │
          │ - Request list           │
          │ - Charts                 │
          │ - Statistics             │
          │ - Action buttons         │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Admin Updates Status     │
          │ Click "Resolve" button   │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ PATCH /admin/requests/:id│
          │ {status: "resolved"}     │
          └────────┬─────────────────┘
                   ↓
              ┌────────────────┐
              │  Backend       │
              │  Updates DB    │
              │  + timestamps  │
              └────────┬───────┘
                       ↓
              ┌────────────────┐
              │ Returns Updated│
              │ Request Object │
              └────────┬───────┘
                       ↓
          ✅ Status Updated
             (Auto-refresh
             shows change)
             
             
3. SUPER ADMIN (Viewing Overview)
   ┌──────────────┐
   │  Login Page  │
   └──────┬───────┘
          │
          ├──→ Enter admin/admin123
          │
          └──→ Click Sign In
              ↓
          ┌──────────────────┐
          │ Verify Credentials
          │ Issue JWT Token  │
          └────────┬─────────┘
                   ↓
          ┌──────────────────────────┐
          │ Redirect to Overview     │
          │ /admin/dashboard/overview│
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Load Stats for All 7     │
          │ Services (Parallel)      │
          │ GET /admin/stats (each)  │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Display:                 │
          │ - Global stats           │
          │ - Service cards          │
          │ - Comparison table       │
          │ - Performance metrics    │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Click Service Card       │
          │ (e.g., Fire Service)     │
          └────────┬─────────────────┘
                   ↓
          ┌──────────────────────────┐
          │ Navigate to Dashboard    │
          │ /admin/dashboard/fire    │
          │ (Same as Step 2)         │
          └──────────────────────────┘
```

---

## Component Hierarchy

```
App
├── QueryClientProvider
├── TooltipProvider
├── BrowserRouter
│   └── Routes
│       ├── Route: /
│       │   └── Index
│       │       ├── HeroSection
│       │       ├── CategoryFilter
│       │       ├── ServiceCard (×multiple)
│       │       │   └── RequestModal
│       │       │       └── Form Inputs
│       │       └── Footer
│       │
│       ├── Route: /admin
│       │   └── AdminLoginV2 (NEW)
│       │       ├── Logo Section
│       │       ├── Login Form
│       │       ├── Demo Credentials
│       │       └── Services Grid
│       │
│       ├── Route: /admin/old
│       │   └── AdminLogin (Original)
│       │
│       ├── Route: /admin/police
│       │   └── PoliceAdmin (Original)
│       │
│       ├── Route: /admin/dashboard/overview
│       │   └── SuperAdminOverview (NEW)
│       │       ├── Header
│       │       ├── StatCard (×4)
│       │       ├── ServiceCard (×7)
│       │       └── Comparison Table
│       │
│       ├── Route: /admin/dashboard/:category
│       │   └── ServiceDashboard (NEW)
│       │       ├── Header
│       │       ├── StatCard (×4)
│       │       ├── BarChart
│       │       ├── PieChart
│       │       ├── Filter Tabs
│       │       ├── RequestTable
│       │       │   └── TableRow (×multiple)
│       │       └── MetricsCards
│       │
│       └── Route: *
│           └── NotFound
│
└── Toast System + Toaster
```

---

## Database Schema

```
db.json
├── providers: Provider[]
│   └── {
│       id: string (UUID)
│       name: string
│       category: string (police|fire|ambulance|...)
│       phone: string
│       address: string
│       rating: number (0-5)
│       available: boolean
│       description: string
│       responseTime: string
│       agentName: string
│       agentPhone: string
│   }
│
├── requests: Request[]
│   └── {
│       id: string (req_timestamp_random)
│       providerId: string
│       providerName: string
│       category: string (police|fire|ambulance|...)
│       customerName: string
│       customerPhone: string
│       customerAddress: string
│       details: string
│       status: string (pending|attended|resolved)
│       createdAt: ISO8601
│       attendedAt?: ISO8601
│       resolvedAt?: ISO8601
│   }
│
└── admins: Admin[]
    └── {
        username: string
        password: string (plain text for demo)
        role: string (police|fire|ambulance|...|super-admin)
    }
```

---

## Authentication & Authorization Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    JWT AUTH FLOW                                │
└─────────────────────────────────────────────────────────────────┘

1. LOGIN REQUEST
   ┌──────────────────────────────────┐
   │ POST /api/admin/login            │
   │ {                                │
   │   username: "police",            │
   │   password: "police123"          │
   │ }                                │
   └────────┬─────────────────────────┘
            ↓
   ┌──────────────────────────────────┐
   │ Backend validates credentials    │
   │ in admins array                  │
   └────┬───────────────────────────┬─┘
        │ Valid                     │ Invalid
        ↓                           ↓
   ┌──────────────────┐    ┌──────────────────┐
   │ Create JWT Token │    │ 401 Unauthorized │
   │ payload:         │    │ (Error response) │
   │ {                │    └──────────────────┘
   │   username,      │
   │   role: "police" │
   │ }                │
   │ expiresIn: "8h"  │
   └────────┬─────────┘
            ↓
   ┌──────────────────────────────────┐
   │ Return to Frontend:              │
   │ {                                │
   │   token: "eyJhbGc...",          │
   │   role: "police"                 │
   │ }                                │
   └────────┬─────────────────────────┘
            ↓
2. STORE TOKEN
   ┌──────────────────────────────────┐
   │ localStorage.setItem(            │
   │   "admin_token",                 │
   │   token                          │
   │ )                                │
   │ localStorage.setItem(            │
   │   "admin_role",                  │
   │   role                           │
   │ )                                │
   └────────┬─────────────────────────┘
            ↓
3. PROTECTED ROUTE REQUEST
   ┌──────────────────────────────────┐
   │ GET /api/admin/requests          │
   │ Headers: {                       │
   │   Authorization: "Bearer token"  │
   │ }                                │
   └────────┬─────────────────────────┘
            ↓
   ┌──────────────────────────────────┐
   │ Backend middleware:              │
   │ authRequired()                   │
   │                                  │
   │ - Extract token from header      │
   │ - Verify JWT signature           │
   │ - Check expiration               │
   │ - Decode payload                 │
   └────┬──────────────────────────┬──┘
        │ Valid                    │ Invalid
        ↓                          ↓
   ┌──────────────────┐   ┌──────────────────┐
   │ Extract role     │   │ 401 Unauthorized │
   │ from payload     │   │ (redirect login) │
   │                  │   └──────────────────┘
   │ Check role-based │
   │ permissions      │
   │                  │
   │ Filter data by   │
   │ role/category    │
   └────────┬─────────┘
            ↓
   ┌──────────────────────────────────┐
   │ Return filtered data             │
   │ (Only own service's requests)    │
   └──────────────────────────────────┘

4. ROLE-BASED FILTERING

   Police Admin requesting /api/admin/requests
   ├─ Get all requests from DB
   ├─ Filter: category === "police"
   └─ Return: Only police requests
   
   Super Admin requesting /api/admin/requests
   ├─ Get all requests from DB
   ├─ No filtering (super-admin)
   └─ Return: ALL requests
   
   Super Admin requesting /api/admin/requests?category=fire
   ├─ Get all requests from DB
   ├─ Filter: category === "fire"
   └─ Return: Only fire requests
```

---

## Real-time Update Cycle

```
┌────────────────────────────────────────────────────────────────┐
│              DASHBOARD AUTO-REFRESH CYCLE                      │
└────────────────────────────────────────────────────────────────┘

Initial Load
│
├─→ useEffect hook triggered
│   ├─ Check authentication (token exists)
│   ├─ Check authorization (role matches route)
│   └─ Call load() function
│       ├─ GET /api/admin/requests
│       └─ GET /api/admin/stats
│
├─→ Data received
│   ├─ setRequests(data)
│   └─ setStats(data)
│
├─→ Components re-render
│   ├─ Stats cards update
│   ├─ Charts update
│   └─ Request table updates
│
└─→ Set interval: setInterval(load, 5000)
    │
    └─→ Every 5 seconds:
        ├─ Call load() again
        ├─ Fetch fresh data
        ├─ Update UI if changed
        └─ Check for new requests
        
        If data changed:
        ├─ Stats cards flash/update
        ├─ New requests appear at top
        ├─ Charts rebuild
        └─ Toast notification (optional)
        
Cleanup
└─→ When component unmounts:
    ├─ Clear interval
    └─ Stop API calls
```

---

## Request Status Lifecycle

```
TIMELINE VIEW:

┌─────────────────────────────────────────────────────────────┐
│                 REQUEST LIFECYCLE                           │
└─────────────────────────────────────────────────────────────┘

T0: Request Submitted
├─ createdAt = NOW
├─ status = "pending"
├─ attendedAt = null
├─ resolvedAt = null
└─ 🔴 Appears in Pending tab

    ↓ (Optional) Admin clicks "Attend"
    
T1: Request Attended
├─ attendedAt = NOW
├─ status = "attended"
├─ resolvedAt = null
└─ 🟣 Moves to Attended tab

    ↓ Admin clicks "Resolve"
    
T2: Request Resolved
├─ attendedAt = (unchanged from T1)
├─ resolvedAt = NOW
├─ status = "resolved"
└─ 🟢 Moves to Resolved tab

ALTERNATIVE PATH:

T0: Request Submitted
├─ status = "pending"
└─ 🔴 Appears in Pending tab

    ↓ (Skip Attend) Admin clicks "Resolve"
    
T2: Request Resolved
├─ attendedAt = null (skipped)
├─ resolvedAt = NOW
├─ status = "resolved"
└─ 🟢 Moves to Resolved tab


METRICS BASED ON TIMELINE:

Response Time = attendedAt - createdAt
               (or resolvedAt if no attendedAt)

Resolution Time = resolvedAt - createdAt

Activity Chart:
- Received: Count by createdAt date
- Attended: Count by attendedAt date
```

---

## File Structure

```
csapp-enhanced/
│
├── backend/
│   ├── server.js (ENHANCED)
│   │   ├─ seedProviders (10 providers)
│   │   ├─ seedAdmins (8 accounts) ✨ NEW
│   │   ├─ Public routes (4)
│   │   ├─ Auth routes (1)
│   │   ├─ Admin routes (3)
│   │   └─ Middleware: authRequired
│   │
│   ├── db.json (Generated on first run)
│   ├── package.json
│   └── .gitignore
│
├── frontend/
│   ├── src/
│   │   ├── App.tsx (ENHANCED)
│   │   │   └─ 2 new routes ✨
│   │   │
│   │   ├── pages/
│   │   │   ├─ Index.tsx (Home)
│   │   │   ├─ NotFound.tsx
│   │   │   ├─ AdminLogin.tsx (Original)
│   │   │   ├─ AdminLoginV2.tsx (NEW) ✨
│   │   │   ├─ PoliceAdmin.tsx (Original)
│   │   │   ├─ ServiceDashboard.tsx (NEW) ✨
│   │   │   └─ SuperAdminOverview.tsx (NEW) ✨
│   │   │
│   │   ├── components/
│   │   │   ├─ HeroSection.tsx
│   │   │   ├─ ServiceCard.tsx
│   │   │   ├─ CategoryFilter.tsx
│   │   │   ├─ RequestModal.tsx
│   │   │   ├─ Footer.tsx
│   │   │   └─ ui/ (shadcn/ui components)
│   │   │
│   │   ├── lib/
│   │   │   ├─ api.ts (API client)
│   │   │   └─ utils.ts
│   │   │
│   │   └── data/
│   │       └─ services.ts
│   │
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.ts
│   ├── vite.config.ts
│   └── tsconfig.json
│
├── DASHBOARD_FEATURES.md (NEW) ✨
├── SETUP_AND_TESTING.md (NEW) ✨
├── QUICK_REFERENCE.md (NEW) ✨
├── ENHANCEMENT_SUMMARY.md (NEW) ✨
└── README.md
```

---

## Performance Optimization

```
┌──────────────────────────────────────────────────────────────┐
│          PERFORMANCE CONSIDERATIONS                          │
└──────────────────────────────────────────────────────────────┘

1. API CALL OPTIMIZATION
   - Service Dashboard: 2 calls every 5s
   - Super Admin: 7 parallel calls every 10s (less frequent)
   - Request table filtered client-side (no extra API)
   
2. DATA LOADING
   - Parallel Promise.all() for multiple stats
   - No unnecessary re-renders
   - useCallback prevents function recreation
   
3. CHART RENDERING
   - Recharts handles large datasets well
   - Charts update on data change
   - No animations on every refresh
   
4. LOCAL CACHING
   - localStorage for tokens (no repeated login)
   - In-memory state for requests/stats
   - No IndexedDB needed
   
5. NETWORK OPTIMIZATION
   - Single JSON database (no DB overhead)
   - REST API (simple, no GraphQL complexity)
   - CORS enabled for cross-origin
   
6. MEMORY MANAGEMENT
   - setInterval cleared on unmount
   - No memory leaks
   - useEffect cleanup functions
```

---

## Scalability Roadmap

```
CURRENT (v3.0 - Local)
├─ JSON file storage
├─ Single server process
├─ In-memory data
└─ Works for < 10 concurrent users

FUTURE (v4.0 - Production)
├─ PostgreSQL/MongoDB database
├─ Multiple server instances
├─ Redis caching
├─ Load balancing
└─ Supports 100+ concurrent users

FUTURE (v5.0 - Enterprise)
├─ Microservices architecture
├─ Real-time WebSocket updates
├─ Advanced analytics
├─ Mobile app integration
├─ SMS/Email notifications
└─ Supports 1000+ concurrent users
```

---

**This architecture enables a robust, scalable community service management system.**

**Status**: ✅ Production Ready for Current Scale
