/**
 * CommunityHub Backend
 * - Public API: providers, categories, request submission
 * - Admin API (police): login, list/update requests, dashboard stats
 *
 * Storage: JSON file (db.json) — simple persistence, no external DB needed.
 */
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "communityhub-dev-secret-change-me";
const DB_FILE = path.join(__dirname, "db.json");

app.use(cors());
app.use(express.json());

// ---------- Persistence helpers ----------
const seedProviders = [
  { id: "1", name: "City Police Station", category: "police", phone: "100", address: "Main Road, Downtown", rating: 4.5, available: true, description: "24/7 law enforcement and emergency response", responseTime: "5 min", agentName: "Officer Rajesh Kumar", agentPhone: "+1 555-1001" },
  { id: "2", name: "Central Fire Station", category: "fire", phone: "101", address: "Fire Lane, Sector 12", rating: 4.8, available: true, description: "Fire rescue and prevention services", responseTime: "7 min", agentName: "Capt. Maria Lopez", agentPhone: "+1 555-1002" },
  { id: "3", name: "City Hospital Ambulance", category: "ambulance", phone: "102", address: "Hospital Road, Medical Hub", rating: 4.7, available: true, description: "Emergency medical transport and first aid", responseTime: "8 min", agentName: "Dr. Anil Sharma", agentPhone: "+1 555-1003" },
  { id: "4", name: "QuickFix Plumbing", category: "plumbing", phone: "+1 555-0101", address: "12 Workshop Lane", rating: 4.3, available: true, description: "Pipe repair, installation & emergency leak fixing", responseTime: "30 min", agentName: "Mike Brown", agentPhone: "+1 555-0101" },
  { id: "5", name: "PowerLine Electricians", category: "electrical", phone: "+1 555-0202", address: "45 Circuit Ave", rating: 4.6, available: true, description: "Wiring, panel upgrades & emergency power restoration", responseTime: "25 min", agentName: "Sara Patel", agentPhone: "+1 555-0202" },
  { id: "6", name: "SparkSafe Electrical", category: "electrical", phone: "+1 555-0203", address: "78 Voltage St", rating: 4.2, available: false, description: "Licensed electrical inspections and repairs", responseTime: "45 min", agentName: "Tom Wilson", agentPhone: "+1 555-0203" },
  { id: "7", name: "DrainMaster Plumbing", category: "plumbing", phone: "+1 555-0104", address: "33 Pipe Road", rating: 4.0, available: true, description: "Drain cleaning, water heater service", responseTime: "40 min", agentName: "Greg Lee", agentPhone: "+1 555-0104" },
  { id: "8", name: "CleanSweep Services", category: "cleaning", phone: "+1 555-0301", address: "9 Fresh Blvd", rating: 4.4, available: true, description: "Home and office deep cleaning services", responseTime: "1 hr", agentName: "Linda Garcia", agentPhone: "+1 555-0301" },
  { id: "9", name: "BugAway Pest Control", category: "pest-control", phone: "+1 555-0401", address: "21 Shield Lane", rating: 4.1, available: true, description: "Termite, rodent & insect extermination", responseTime: "2 hrs", agentName: "Rahul Singh", agentPhone: "+1 555-0401" },
  { id: "10", name: "Emergency Helpline", category: "emergency", phone: "112", address: "Citywide Coverage", rating: 4.9, available: true, description: "Universal emergency dispatch center", responseTime: "3 min", agentName: "Control Room", agentPhone: "112" }
];

const seedAdmins = [
  { username: "police", password: "police123", role: "police" },
  { username: "fire", password: "fire123", role: "fire" },
  { username: "ambulance", password: "ambulance123", role: "ambulance" },
  { username: "plumbing", password: "plumbing123", role: "plumbing" },
  { username: "electrical", password: "electrical123", role: "electrical" },
  { username: "cleaning", password: "cleaning123", role: "cleaning" },
  { username: "pest-control", password: "pest123", role: "pest-control" },
  { username: "admin", password: "admin123", role: "super-admin" }
];

function loadDB() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = { providers: seedProviders, requests: [], admins: seedAdmins };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ---------- Auth middleware ----------
function authRequired(req, res, next) {
  const auth = req.headers.authorization || "";
  const token = auth.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
}

// ---------- Public routes ----------
app.get("/api/health", (_req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.get("/api/categories", (_req, res) => {
  res.json([
    { id: "police", label: "Police", icon: "🚔", emergency: true },
    { id: "fire", label: "Fire Service", icon: "🚒", emergency: true },
    { id: "ambulance", label: "Ambulance", icon: "🚑", emergency: true },
    { id: "plumbing", label: "Plumber", icon: "🔧", emergency: false },
    { id: "electrical", label: "Electrician", icon: "⚡", emergency: false },
    { id: "cleaning", label: "Cleaning", icon: "🧹", emergency: false },
    { id: "pest-control", label: "Pest Control", icon: "🐛", emergency: false },
    { id: "emergency", label: "General Emergency", icon: "🆘", emergency: true }
  ]);
});

app.get("/api/providers", (req, res) => {
  const db = loadDB();
  const { q, category } = req.query;
  let list = db.providers;
  if (category) list = list.filter((p) => p.category === category);
  if (q) {
    const s = String(q).toLowerCase();
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(s) ||
        p.description.toLowerCase().includes(s) ||
        p.category.includes(s)
    );
  }
  res.json(list);
});

app.post("/api/requests", (req, res) => {
  const { providerId, customerName, customerPhone, customerAddress, details } = req.body || {};
  if (!providerId || !customerName || !customerPhone) {
    return res.status(400).json({ error: "providerId, customerName and customerPhone are required" });
  }
  const db = loadDB();
  const provider = db.providers.find((p) => p.id === providerId);
  if (!provider) return res.status(404).json({ error: "Provider not found" });

  const request = {
    id: `req_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    providerId,
    providerName: provider.name,
    category: provider.category,
    customerName,
    customerPhone,
    customerAddress: customerAddress || "",
    details: details || "",
    status: "pending",
    createdAt: new Date().toISOString()
  };
  db.requests.unshift(request);
  saveDB(db);
  res.status(201).json(request);
});

// ---------- Admin routes ----------
app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  const db = loadDB();
  const admin = db.admins.find((a) => a.username === username && a.password === password);
  if (!admin) return res.status(401).json({ error: "Invalid credentials" });
  const token = jwt.sign({ username: admin.username, role: admin.role }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ token, role: admin.role });
});

app.get("/api/admin/requests", authRequired, (req, res) => {
  const db = loadDB();
  const { category } = req.query;
  let list = db.requests;
  
  // Restrict each admin to their own category (unless super-admin)
  if (req.user.role !== "super-admin") {
    list = list.filter((r) => r.category === req.user.role);
  } else if (category) {
    // Super-admin can filter by category if specified
    list = list.filter((r) => r.category === category);
  }
  res.json(list);
});

app.patch("/api/admin/requests/:id", authRequired, (req, res) => {
  const { status } = req.body || {};
  if (!["pending", "attended", "resolved"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }
  const db = loadDB();
  const r = db.requests.find((x) => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: "Not found" });
  
  // Only allow if request category matches user's role (or super-admin)
  if (req.user.role !== "super-admin" && r.category !== req.user.role) {
    return res.status(403).json({ error: "Forbidden" });
  }
  
  r.status = status;
  if (status === "attended" && !r.attendedAt) r.attendedAt = new Date().toISOString();
  if (status === "resolved" && !r.resolvedAt) r.resolvedAt = new Date().toISOString();
  saveDB(db);
  res.json(r);
});

app.get("/api/admin/stats", authRequired, (req, res) => {
  const db = loadDB();
  let category;
  
  // Determine which category to report on
  if (req.user.role === "super-admin") {
    category = req.query.category; // Super-admin can request any category
  } else {
    category = req.user.role; // Regular admins get their own category
  }
  
  const list = category ? db.requests.filter((r) => r.category === category) : db.requests;

  const total = list.length;
  const pending = list.filter((r) => r.status === "pending").length;
  const attended = list.filter((r) => r.status === "attended").length;
  const resolved = list.filter((r) => r.status === "resolved").length;

  // Last 7 days bucket
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    days.push({
      date: key.slice(5), // MM-DD
      received: list.filter((r) => r.createdAt.slice(0, 10) === key).length,
      attended: list.filter((r) => (r.attendedAt || r.resolvedAt || "").slice(0, 10) === key).length
    });
  }

  res.json({ total, pending, attended, resolved, perDay: days });
});

// ---------- Boot ----------
loadDB(); // ensure file exists
app.listen(PORT, () => {
  console.log(`✅ CommunityHub backend running on http://localhost:${PORT}`);
  console.log(`   Demo Admin Credentials:`);
  console.log(`   - police / police123`);
  console.log(`   - fire / fire123`);
  console.log(`   - ambulance / ambulance123`);
  console.log(`   - plumbing / plumbing123`);
  console.log(`   - electrical / electrical123`);
  console.log(`   - cleaning / cleaning123`);
  console.log(`   - pest-control / pest123`);
  console.log(`   - admin / admin123 (Super-admin - all services)`);
});
