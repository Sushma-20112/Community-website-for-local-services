# CommunityHub — Full-Stack Community Service App

A one-stop emergency & utility service hub.
- **Citizens** can search providers (Police, Fire, Ambulance, Plumber, Electrician, …), call them directly, or submit a service request with their phone & address.
- **Police Admin** has its own dashboard to view incoming requests, mark them **Attended** / **Resolved**, and see live stats (received vs attended).

```
community-service-fullstack/
├── backend/      Node.js + Express REST API (JSON file storage)
└── frontend/     React + Vite + TypeScript + Tailwind UI
```

---

## 1) Run the backend

```bash
cd backend
npm install
npm run dev          # http://localhost:5000
```

The API will create `db.json` automatically on first run.

### API Endpoints

Public:
- `GET  /api/health`
- `GET  /api/categories`
- `GET  /api/providers?q=&category=`
- `POST /api/requests`               body: `{ providerId, customerName, customerPhone, customerAddress, details }`

Admin (Bearer token from `/admin/login`):
- `POST  /api/admin/login`           body: `{ username, password }`
- `GET   /api/admin/requests`        police role auto-filters to police category
- `PATCH /api/admin/requests/:id`    body: `{ status: "pending"|"attended"|"resolved" }`
- `GET   /api/admin/stats`           returns totals + last 7 days chart data

---

## 2) Run the frontend

```bash
cd frontend
npm install
npm run dev          # http://localhost:8080
```

Optional — copy `.env.example` to `.env` to point at a non-default backend URL.

### Routes
- `/`              — Citizen home (browse, search, request a service)
- `/admin`         — Admin login
- `/admin/police`  — Police dashboard (requires login)

### Demo login
| Role   | Username | Password   |
|--------|----------|------------|
| Police | police   | police123  |

---

## Common errors & fixes

**`Cannot find package 'lovable-tagger'`** — already removed from `vite.config.ts` in this bundle.

**`Failed to resolve import "next-themes"`** — `src/components/ui/sonner.tsx` is patched to detect theme via the `<html class="dark">` attribute, no extra dependency needed.

**Port already in use** — change `PORT=5001 npm run dev` (backend) or `--port 8081` (frontend). Then update `frontend/.env` → `VITE_API_URL=http://localhost:5001/api`.

**Requests don't appear in admin** — confirm both servers are running and that `VITE_API_URL` points at the backend. Check the browser DevTools → Network tab for `/api/requests`.

---

## Tech stack

**Backend:** Node.js · Express · jsonwebtoken · CORS · file-based JSON store
**Frontend:** React 18 · Vite · TypeScript · Tailwind CSS · shadcn/ui · Recharts · React Router · React Query
