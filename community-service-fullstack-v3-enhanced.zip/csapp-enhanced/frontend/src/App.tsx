import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import AdminLogin from "./pages/AdminLogin.tsx";
import AdminLoginV2 from "./pages/AdminLoginV2.tsx";
import PoliceAdmin from "./pages/PoliceAdmin.tsx";
import ServiceDashboard from "./pages/ServiceDashboard.tsx";
import SuperAdminOverview from "./pages/SuperAdminOverview.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/admin" element={<AdminLoginV2 />} />
          <Route path="/admin/old" element={<AdminLogin />} />
          <Route path="/admin/police" element={<PoliceAdmin />} />
          <Route path="/admin/dashboard/overview" element={<SuperAdminOverview />} />
          <Route path="/admin/dashboard/:category" element={<ServiceDashboard />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
