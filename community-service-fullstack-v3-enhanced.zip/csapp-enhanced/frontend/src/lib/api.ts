// API client for backend
const API_BASE = (import.meta.env.VITE_API_URL as string) || "http://localhost:5000/api";

export interface ApiProvider {
  id: string;
  name: string;
  category: string;
  phone: string;
  address: string;
  rating: number;
  available: boolean;
  description: string;
  responseTime: string;
  agentName?: string;
  agentPhone?: string;
}

export interface ServiceRequest {
  id: string;
  providerId: string;
  providerName: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  details: string;
  status: "pending" | "attended" | "resolved";
  createdAt: string;
  attendedAt?: string;
}

async function http<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
    ...opts,
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

export const api = {
  getProviders: (q?: string, category?: string) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category && category !== "all") params.set("category", category);
    return http<ApiProvider[]>(`/providers?${params}`);
  },
  createRequest: (data: Omit<ServiceRequest, "id" | "status" | "createdAt" | "providerName">) =>
    http<ServiceRequest>("/requests", { method: "POST", body: JSON.stringify(data) }),
  // Admin
  login: (username: string, password: string) =>
    http<{ token: string; role: string }>("/admin/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),
  getRequests: (token: string, category: string) =>
    http<ServiceRequest[]>(`/admin/requests?category=${category}`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
  updateRequestStatus: (token: string, id: string, status: ServiceRequest["status"]) =>
    http<ServiceRequest>(`/admin/requests/${id}`, {
      method: "PATCH",
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status }),
    }),
  getStats: (token: string, category: string) =>
    http<{
      total: number;
      pending: number;
      attended: number;
      resolved: number;
      perDay: { date: string; received: number; attended: number }[];
    }>(`/admin/stats?category=${category}`, {
      headers: { Authorization: `Bearer ${token}` },
    }),
};
