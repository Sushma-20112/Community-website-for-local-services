import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Shield, LogOut, Inbox, CheckCircle2, Clock, TrendingUp, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "@/hooks/use-toast";
import { api, ServiceRequest } from "@/lib/api";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const CATEGORY = "police";

const StatCard = ({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Inbox;
  label: string;
  value: number;
  tone: "blue" | "amber" | "green" | "purple";
}) => {
  const toneMap = {
    blue: "bg-service-blue/15 text-service-blue",
    amber: "bg-service-amber/15 text-service-amber",
    green: "bg-service-green/15 text-service-green",
    purple: "bg-service-purple/15 text-service-purple",
  };
  return (
    <div className="bg-card rounded-2xl border border-border p-5 shadow-card">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${toneMap[tone]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <p className="font-display text-3xl font-bold text-card-foreground">{value}</p>
    </div>
  );
};

const PoliceAdmin = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("admin_token");
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    attended: 0,
    resolved: 0,
    perDay: [] as { date: string; received: number; attended: number }[],
  });

  const load = useCallback(async () => {
    if (!token) return;
    try {
      const [r, s] = await Promise.all([api.getRequests(token, CATEGORY), api.getStats(token, CATEGORY)]);
      setRequests(r);
      setStats(s);
    } catch {
      toast({ title: "Session expired", variant: "destructive" });
      navigate("/admin");
    }
  }, [token, navigate]);

  useEffect(() => {
    if (!token) {
      navigate("/admin");
      return;
    }
    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [token, navigate, load]);

  const handleStatus = async (id: string, status: ServiceRequest["status"]) => {
    if (!token) return;
    try {
      await api.updateRequestStatus(token, id, status);
      toast({ title: `Marked as ${status}` });
      load();
    } catch {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  const logout = () => {
    localStorage.removeItem("admin_token");
    localStorage.removeItem("admin_role");
    navigate("/admin");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-service-blue/15 flex items-center justify-center">
              <Shield className="w-5 h-5 text-service-blue" />
            </div>
            <div>
              <h1 className="font-display font-bold text-lg text-card-foreground">Police Admin Dashboard</h1>
              <p className="text-xs text-muted-foreground">Live service request management</p>
            </div>
          </div>
          <Button variant="outline" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Stats */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Inbox} label="Total Received" value={stats.total} tone="blue" />
          <StatCard icon={Clock} label="Pending" value={stats.pending} tone="amber" />
          <StatCard icon={TrendingUp} label="Attended" value={stats.attended} tone="purple" />
          <StatCard icon={CheckCircle2} label="Resolved" value={stats.resolved} tone="green" />
        </section>

        {/* Chart */}
        <section className="bg-card rounded-2xl border border-border p-6 shadow-card">
          <h2 className="font-display text-lg font-bold mb-4 text-card-foreground">Activity (Last 7 days)</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.perDay}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.75rem",
                  }}
                />
                <Legend />
                <Bar dataKey="received" fill="hsl(var(--service-blue))" radius={[6, 6, 0, 0]} />
                <Bar dataKey="attended" fill="hsl(var(--service-green))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Requests Table */}
        <section className="bg-card rounded-2xl border border-border shadow-card overflow-hidden">
          <div className="p-6 border-b border-border">
            <h2 className="font-display text-lg font-bold text-card-foreground">Incoming Requests</h2>
            <p className="text-sm text-muted-foreground">Auto-refreshes every 5s</p>
          </div>
          {requests.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Inbox className="w-12 h-12 mx-auto mb-3 opacity-40" />
              No requests yet. They'll appear here when citizens submit them.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Citizen</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requests.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.customerName}</TableCell>
                    <TableCell>
                      <a
                        href={`tel:${r.customerPhone}`}
                        className="flex items-center gap-1.5 text-service-blue hover:underline"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        {r.customerPhone}
                      </a>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5" />
                        {r.customerAddress || "—"}
                      </span>
                    </TableCell>
                    <TableCell className="max-w-xs text-sm text-muted-foreground truncate">
                      {r.details || "—"}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(r.createdAt).toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          r.status === "resolved"
                            ? "default"
                            : r.status === "attended"
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {r.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      {r.status === "pending" && (
                        <Button size="sm" variant="outline" onClick={() => handleStatus(r.id, "attended")}>
                          Attend
                        </Button>
                      )}
                      {r.status !== "resolved" && (
                        <Button size="sm" onClick={() => handleStatus(r.id, "resolved")}>
                          Resolve
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </section>
      </main>
    </div>
  );
};

export default PoliceAdmin;
