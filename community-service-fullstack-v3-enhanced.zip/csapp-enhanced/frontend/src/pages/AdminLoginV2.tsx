import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Lock, LogIn, Shield, AlertCircle, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

const SERVICES = [
  { id: "police", label: "Police", icon: "🚔" },
  { id: "fire", label: "Fire Service", icon: "🚒" },
  { id: "ambulance", label: "Ambulance", icon: "🚑" },
  { id: "plumbing", label: "Plumbing", icon: "🔧" },
  { id: "electrical", label: "Electrical", icon: "⚡" },
  { id: "cleaning", label: "Cleaning", icon: "🧹" },
  { id: "pest-control", label: "Pest Control", icon: "🐛" },
  { id: "admin", label: "Super Admin", icon: "👑" },
];

const DEMO_CREDENTIALS = [
  { username: "police", password: "police123" },
  { username: "fire", password: "fire123" },
  { username: "ambulance", password: "ambulance123" },
  { username: "plumbing", password: "plumbing123" },
  { username: "electrical", password: "electrical123" },
  { username: "cleaning", password: "cleaning123" },
  { username: "pest-control", password: "pest123" },
  { username: "admin", password: "admin123" },
];

const AdminLogin = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showDemoCredentials, setShowDemoCredentials] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("admin_token");
    const role = localStorage.getItem("admin_role");
    if (token && role) {
      if (role === "super-admin") {
        navigate("/admin/dashboard/overview");
      } else {
        navigate(`/admin/dashboard/${role}`);
      }
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({ title: "Please enter both username and password", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const result = await api.adminLogin(username, password);
      localStorage.setItem("admin_token", result.token);
      localStorage.setItem("admin_role", result.role);

      toast({ title: `✓ Welcome back, ${username}!`, description: "Redirecting to dashboard..." });

      if (result.role === "super-admin") {
        navigate("/admin/dashboard/overview");
      } else {
        navigate(`/admin/dashboard/${result.role}`);
      }
    } catch (err) {
      toast({
        title: "Login failed",
        description: err instanceof Error ? err.message : "Invalid credentials",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fillDemoCredentials = (service: string) => {
    const creds = DEMO_CREDENTIALS.find((c) => c.username === service);
    if (creds) {
      setUsername(creds.username);
      setPassword(creds.password);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-500/20 mb-4">
            <Shield className="w-8 h-8 text-blue-400" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Admin Portal</h1>
          <p className="text-slate-400">Service Management Dashboard</p>
        </div>

        {/* Login Card */}
        <Card className="p-8 backdrop-blur-xl bg-white/5 border-white/10">
          <form onSubmit={handleLogin} className="space-y-6">
            {/* Username Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Username</label>
              <Input
                type="text"
                placeholder="Enter your username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-slate-400"
                disabled={loading}
              />
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Password</label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 pr-10"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Login Button */}
            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={loading}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Signing in...
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </>
              )}
            </Button>
          </form>

          {/* Demo Info */}
          <div className="mt-6 pt-6 border-t border-white/10">
            <button
              type="button"
              onClick={() => setShowDemoCredentials(!showDemoCredentials)}
              className="text-sm text-blue-400 hover:text-blue-300 flex items-center gap-2 mb-3"
            >
              <AlertCircle className="w-4 h-4" />
              {showDemoCredentials ? "Hide" : "Show"} demo credentials
            </button>

            {showDemoCredentials && (
              <div className="space-y-2">
                <p className="text-xs text-slate-400 mb-3">Click to auto-fill credentials:</p>
                <div className="grid grid-cols-2 gap-2">
                  {SERVICES.map((service) => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => fillDemoCredentials(service.id)}
                      className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition text-xs text-slate-300 hover:text-white flex items-center gap-2"
                    >
                      <span>{service.icon}</span>
                      <span className="truncate">{service.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Info Banner */}
        <Alert className="mt-6 bg-blue-500/10 border-blue-500/20">
          <Shield className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-200 ml-2">
            Each service has its own dashboard to manage incoming requests and track response metrics.
          </AlertDescription>
        </Alert>

        {/* Services Grid */}
        <div className="mt-8">
          <p className="text-sm text-slate-400 mb-4 text-center">Available Services</p>
          <div className="grid grid-cols-4 gap-3">
            {SERVICES.map((service) => (
              <div key={service.id} className="text-center">
                <div className="text-2xl mb-2">{service.icon}</div>
                <p className="text-xs text-slate-400">{service.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-xs text-slate-500">
          <p>CommunityHub Admin Panel v3.0</p>
          <p className="mt-1">For authorized personnel only</p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
