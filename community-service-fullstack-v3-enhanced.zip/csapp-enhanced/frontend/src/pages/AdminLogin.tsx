import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

const AdminLogin = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("police");
  const [password, setPassword] = useState("police123");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { token, role } = await api.login(username, password);
      localStorage.setItem("admin_token", token);
      localStorage.setItem("admin_role", role);
      toast({ title: "Welcome, Officer 👮", description: "Login successful" });
      navigate("/admin/police");
    } catch {
      toast({ title: "Invalid credentials", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-hero px-4">
      <div className="w-full max-w-md bg-card rounded-2xl shadow-card-hover p-8">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-service-blue/15 flex items-center justify-center mb-3">
            <Shield className="w-8 h-8 text-service-blue" />
          </div>
          <h1 className="font-display text-2xl font-bold text-card-foreground">Police Admin Portal</h1>
          <p className="text-sm text-muted-foreground mt-1">Sign in to manage service requests</p>
        </div>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <Label htmlFor="u">Username</Label>
            <Input id="u" value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="p">Password</Label>
            <Input id="p" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </Button>
          <p className="text-xs text-muted-foreground text-center pt-2">
            Demo: <code className="bg-muted px-1.5 py-0.5 rounded">police</code> /{" "}
            <code className="bg-muted px-1.5 py-0.5 rounded">police123</code>
          </p>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
