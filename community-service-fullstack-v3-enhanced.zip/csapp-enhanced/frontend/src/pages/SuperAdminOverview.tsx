import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { LogOut, BarChart3, TrendingUp, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

interface ServiceStats {
  category: string;
  label: string;
  icon: string;
  total: number;
  pending: number;
  attended: number;
  resolved: number;
}

const CATEGORIES = [
  { id: "police", label: "Police", icon: "🚔" },
  { id: "fire", label: "Fire Service", icon: "🚒" },
  { id: "ambulance", label: "Ambulance", icon: "🚑" },
  { id: "plumbing", label: "Plumbing", icon: "🔧" },
  { id: "electrical", label: "Electrical", icon: "⚡" },
  { id: "cleaning", label: "Cleaning", icon: "🧹" },
  { id: "pest-control", label: "Pest Control", icon: "🐛" },
];

const SuperAdminOverview = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("admin_token");
  const role = localStorage.getItem("admin_role");
  const [serviceStats, setServiceStats] = useState<ServiceStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);

  const loadStats = useCallback(async () => {
    if (!token) return;
    try {
      setLoading(true);
      const statsPromises = CATEGORIES.map((cat) =>
        api.getStats(token, cat.id).then((s) => ({
          category: cat.id,
          label: cat.label,
          icon: cat.icon,
          ...s,
        }))
      );
      const results = await Promise.all(statsPromises);
      setServiceStats(results);
    } catch (err) {
      toast({ title: "Failed to load statistics", variant: "destructive" });
      navigate("/admin");
    } finally {
      setLoading(false);
    }
  }, [token, navigate]);

  useEffect(() => {
    if (!token || role !== "super-admin") {
      navigate("/admin");
      return;
    }

    loadStats();
    const interval = setInterval(loadStats, 10000);
    setRefreshInterval(interval);

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [token, role, navigate, loadStats]);

  const logout = () => {
    localStorage.removeItem("admin_token");
    localStorage.removeItem("admin_role");
    navigate("/admin");
  };

  const totalRequests = serviceStats.reduce((sum, s) => sum + s.total, 0);
  const totalPending = serviceStats.reduce((sum, s) => sum + s.pending, 0);
  const totalResolved = serviceStats.reduce((sum, s) => sum + s.resolved, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 flex items-center justify-center text-xl">
              👑
            </div>
            <div>
              <h1 className="font-display font-bold text-lg text-card-foreground">
                CommunityHub Admin Overview
              </h1>
              <p className="text-xs text-muted-foreground">All services at a glance</p>
            </div>
          </div>
          <Button variant="outline" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Global Stats */}
        <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6 border-l-4 border-l-blue-500">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Total Requests</p>
              <BarChart3 className="w-5 h-5 text-blue-500" />
            </div>
            <p className="text-3xl font-bold">{totalRequests}</p>
            <p className="text-xs text-muted-foreground mt-2">Across all services</p>
          </Card>

          <Card className="p-6 border-l-4 border-l-red-500">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Pending</p>
              <TrendingUp className="w-5 h-5 text-red-500" />
            </div>
            <p className="text-3xl font-bold text-red-600">{totalPending}</p>
            <p className="text-xs text-muted-foreground mt-2">Requiring attention</p>
          </Card>

          <Card className="p-6 border-l-4 border-l-green-500">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Resolved</p>
              <Users className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-3xl font-bold text-green-600">{totalResolved}</p>
            <p className="text-xs text-muted-foreground mt-2">Completed</p>
          </Card>

          <Card className="p-6 border-l-4 border-l-purple-500">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-medium text-muted-foreground">Completion Rate</p>
              <Zap className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-3xl font-bold text-purple-600">
              {totalRequests > 0 ? `${Math.round((totalResolved / totalRequests) * 100)}%` : "0%"}
            </p>
            <p className="text-xs text-muted-foreground mt-2">Overall</p>
          </Card>
        </section>

        {/* Service Dashboards Grid */}
        <section>
          <h2 className="text-xl font-bold mb-6 text-card-foreground">Service Dashboard Quick Access</h2>
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(7)].map((_, i) => (
                <Card key={i} className="p-6 animate-pulse">
                  <div className="h-10 bg-muted rounded mb-4" />
                  <div className="h-6 bg-muted rounded mb-4" />
                  <div className="h-4 bg-muted rounded w-24" />
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {serviceStats.map((service) => (
                <Card
                  key={service.category}
                  className="p-6 hover:shadow-lg transition-all cursor-pointer group border-2 border-transparent hover:border-blue-500"
                  onClick={() => navigate(`/admin/dashboard/${service.category}`)}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-3xl">{service.icon}</span>
                        <h3 className="font-bold text-lg text-card-foreground group-hover:text-blue-600 transition">
                          {service.label}
                        </h3>
                      </div>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-blue-500/10 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Total</p>
                      <p className="text-xl font-bold text-blue-600">{service.total}</p>
                    </div>
                    <div className="bg-red-500/10 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Pending</p>
                      <p className="text-xl font-bold text-red-600">{service.pending}</p>
                    </div>
                    <div className="bg-purple-500/10 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Attended</p>
                      <p className="text-xl font-bold text-purple-600">{service.attended}</p>
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-3">
                      <p className="text-xs text-muted-foreground mb-1">Resolved</p>
                      <p className="text-xl font-bold text-green-600">{service.resolved}</p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className="flex items-center justify-between">
                    <Badge
                      variant={service.pending > 0 ? "destructive" : "default"}
                      className="bg-opacity-75"
                    >
                      {service.pending > 0 ? `${service.pending} Pending` : "All Clear"}
                    </Badge>
                    <Button size="sm" variant="ghost" className="group-hover:text-blue-600">
                      View →
                    </Button>
                  </div>

                  {/* Completion Rate */}
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs text-muted-foreground">Completion Rate</span>
                      <span className="text-sm font-bold text-green-600">
                        {service.total > 0 ? `${Math.round((service.resolved / service.total) * 100)}%` : "0%"}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-green-500"
                        style={{
                          width: `${service.total > 0 ? (service.resolved / service.total) * 100 : 0}%`,
                        }}
                      />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Service Comparison Table */}
        {!loading && (
          <section className="bg-card rounded-2xl border border-border p-6">
            <h2 className="text-lg font-bold mb-4 text-card-foreground">Service Comparison</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-muted-foreground">
                    <th className="text-left py-3 px-4 font-semibold">Service</th>
                    <th className="text-right py-3 px-4 font-semibold">Total</th>
                    <th className="text-right py-3 px-4 font-semibold">Pending</th>
                    <th className="text-right py-3 px-4 font-semibold">Attended</th>
                    <th className="text-right py-3 px-4 font-semibold">Resolved</th>
                    <th className="text-right py-3 px-4 font-semibold">Completion %</th>
                  </tr>
                </thead>
                <tbody>
                  {serviceStats.map((service) => (
                    <tr
                      key={service.category}
                      className="border-b border-border hover:bg-muted/50 cursor-pointer"
                      onClick={() => navigate(`/admin/dashboard/${service.category}`)}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span>{service.icon}</span>
                          <span className="font-medium">{service.label}</span>
                        </div>
                      </td>
                      <td className="text-right py-3 px-4 font-bold">{service.total}</td>
                      <td className="text-right py-3 px-4">
                        <Badge variant={service.pending > 0 ? "destructive" : "secondary"}>
                          {service.pending}
                        </Badge>
                      </td>
                      <td className="text-right py-3 px-4 text-purple-600 font-medium">{service.attended}</td>
                      <td className="text-right py-3 px-4 text-green-600 font-medium">{service.resolved}</td>
                      <td className="text-right py-3 px-4 font-bold">
                        {service.total > 0 ? `${Math.round((service.resolved / service.total) * 100)}%` : "0%"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </main>
    </div>
  );
};

export default SuperAdminOverview;
