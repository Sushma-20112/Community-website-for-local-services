import { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { LogOut, Inbox, CheckCircle2, Clock, TrendingUp, Phone, MapPin, Calendar, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { api, ServiceRequest } from "@/lib/api";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";

interface CategoriesType {
  [key: string]: { label: string; icon: string; color: string };
}

const CATEGORIES: CategoriesType = {
  police: { label: "Police", icon: "🚔", color: "hsl(var(--service-blue))" },
  fire: { label: "Fire Service", icon: "🚒", color: "hsl(var(--service-red))" },
  ambulance: { label: "Ambulance", icon: "🚑", color: "hsl(var(--service-orange))" },
  plumbing: { label: "Plumbing", icon: "🔧", color: "hsl(var(--service-purple))" },
  electrical: { label: "Electrical", icon: "⚡", color: "hsl(var(--service-yellow))" },
  cleaning: { label: "Cleaning", icon: "🧹", color: "hsl(var(--service-green))" },
  "pest-control": { label: "Pest Control", icon: "🐛", color: "hsl(var(--service-blue))" },
};

const StatCard = ({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Inbox;
  label: string;
  value: number;
  tone: "blue" | "amber" | "green" | "purple" | "red" | "orange";
}) => {
  const toneMap = {
    blue: "bg-blue-500/15 text-blue-600",
    amber: "bg-amber-500/15 text-amber-600",
    green: "bg-green-500/15 text-green-600",
    purple: "bg-purple-500/15 text-purple-600",
    red: "bg-red-500/15 text-red-600",
    orange: "bg-orange-500/15 text-orange-600",
  };
  return (
    <div className="bg-card rounded-2xl border border-border p-5 shadow-card">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${toneMap[tone]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <p className="font-display text-3xl font-bold text-card-foreground">{value}</p>
    </div>
  );
};

const ServiceDashboard = () => {
  const navigate = useNavigate();
  const { category } = useParams<{ category: string }>();
  const token = localStorage.getItem("admin_token");
  const role = localStorage.getItem("admin_role");
  
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    attended: 0,
    resolved: 0,
    perDay: [] as { date: string; received: number; attended: number }[],
  });
  const [activeTab, setActiveTab] = useState<"pending" | "attended" | "resolved" | "all">("pending");

  const categoryData = category && CATEGORIES[category as keyof typeof CATEGORIES] 
    ? CATEGORIES[category as keyof typeof CATEGORIES]
    : { label: "Unknown", icon: "❓", color: "gray" };

  const load = useCallback(async () => {
    if (!token || !category) return;
    try {
      const [r, s] = await Promise.all([
        api.getRequests(token, category),
        api.getStats(token, category),
      ]);
      setRequests(r);
      setStats(s);
    } catch (err) {
      toast({ title: "Session expired or invalid access", variant: "destructive" });
      navigate("/admin");
    }
  }, [token, category, navigate]);

  useEffect(() => {
    // Verify authorization
    if (!token) {
      navigate("/admin");
      return;
    }
    
    // Check if user has access to this category (unless super-admin)
    if (role !== "super-admin" && role !== category) {
      toast({ title: "Unauthorized access", variant: "destructive" });
      navigate("/admin");
      return;
    }

    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [token, role, category, navigate, load]);

  const handleStatus = async (id: string, status: ServiceRequest["status"]) => {
    if (!token) return;
    try {
      await api.updateRequestStatus(token, id, status);
      toast({ title: `✓ Marked as ${status}`, variant: "default" });
      load();
    } catch {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  const logout = () => {
    localStorage.removeItem("admin_token");
    localStorage.removeItem("admin_role");
    navigate("/admin");
  };

  const filteredRequests = requests.filter((r) => {
    if (activeTab === "all") return true;
    return r.status === activeTab;
  });

  const statusDistribution = [
    { name: "Pending", value: stats.pending, fill: "#f59e0b" },
    { name: "Attended", value: stats.attended, fill: "#a855f7" },
    { name: "Resolved", value: stats.resolved, fill: "#10b981" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/15 flex items-center justify-center text-xl">
              {categoryData.icon}
            </div>
            <div>
              <h1 className="font-display font-bold text-lg text-card-foreground">
                {categoryData.label} Dashboard
              </h1>
              <p className="text-xs text-muted-foreground">Manage service requests in real-time</p>
            </div>
          </div>
          <Button variant="outline" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Key Stats */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Inbox} label="Total Received" value={stats.total} tone="blue" />
          <StatCard icon={Clock} label="Pending" value={stats.pending} tone="amber" />
          <StatCard icon={TrendingUp} label="Attended" value={stats.attended} tone="purple" />
          <StatCard icon={CheckCircle2} label="Resolved" value={stats.resolved} tone="green" />
        </section>

        {/* Charts Row */}
        <section className="grid lg:grid-cols-3 gap-6">
          {/* Activity Chart */}
          <div className="lg:col-span-2 bg-card rounded-2xl border border-border p-6 shadow-card">
            <h2 className="font-display text-lg font-bold mb-4 text-card-foreground">Activity (Last 7 days)</h2>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.perDay}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "0.75rem",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="received" fill="#3b82f6" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="attended" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Status Distribution */}
          <div className="bg-card rounded-2xl border border-border p-6 shadow-card">
            <h2 className="font-display text-lg font-bold mb-4 text-card-foreground">Status Breakdown</h2>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusDistribution.filter((s) => s.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, value }) => `${name} ${value}`}
                  >
                    {statusDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* Requests Table */}
        <section className="bg-card rounded-2xl border border-border shadow-card overflow-hidden">
          <div className="p-6 border-b border-border flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-card-foreground">Service Requests</h2>
              <p className="text-sm text-muted-foreground">Auto-refreshes every 5 seconds</p>
            </div>
            <div className="flex gap-2">
              {(["pending", "attended", "resolved", "all"] as const).map((tab) => (
                <Button
                  key={tab}
                  variant={activeTab === tab ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveTab(tab)}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)} ({
                    tab === "all" ? stats.total : 
                    tab === "pending" ? stats.pending :
                    tab === "attended" ? stats.attended :
                    stats.resolved
                  })
                </Button>
              ))}
            </div>
          </div>

          {filteredRequests.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-40" />
              <p>No {activeTab !== "all" ? activeTab : ""} requests yet.</p>
              <p className="text-xs mt-1">New requests will appear here when citizens submit them.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Citizen Name</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Address</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRequests.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">{r.customerName}</TableCell>
                      <TableCell>
                        <a
                          href={`tel:${r.customerPhone}`}
                          className="flex items-center gap-1.5 text-blue-600 hover:underline"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          {r.customerPhone}
                        </a>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" />
                          {r.customerAddress || "Not specified"}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground max-w-xs">
                        <span className="truncate block">{r.details || "No details provided"}</span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5" />
                          {new Date(r.createdAt).toLocaleString("en-US", {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            r.status === "resolved"
                              ? "default"
                              : r.status === "attended"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-2">
                        {r.status === "pending" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleStatus(r.id, "attended")}
                          >
                            Attend
                          </Button>
                        )}
                        {r.status !== "resolved" && (
                          <Button
                            size="sm"
                            onClick={() => handleStatus(r.id, "resolved")}
                          >
                            Resolve
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </section>

        {/* Request Timeline Stats */}
        {requests.length > 0 && (
          <section className="grid md:grid-cols-3 gap-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-muted-foreground">Avg Response Time</h3>
                <Clock className="w-5 h-5 text-amber-500" />
              </div>
              <p className="text-2xl font-bold">
                {requests.filter((r) => r.attendedAt).length > 0
                  ? "~15-30 min"
                  : "No data"}
              </p>
            </Card>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-muted-foreground">Completion Rate</h3>
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-2xl font-bold">
                {stats.total > 0
                  ? `${Math.round((stats.resolved / stats.total) * 100)}%`
                  : "0%"}
              </p>
            </Card>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-muted-foreground">Pending Requests</h3>
                <AlertCircle className="w-5 h-5 text-red-500" />
              </div>
              <p className="text-2xl font-bold">{stats.pending}</p>
              {stats.pending > 0 && <p className="text-xs text-red-600 mt-2">Requires attention</p>}
            </Card>
          </section>
        )}
      </main>
    </div>
  );
};

export default ServiceDashboard;
