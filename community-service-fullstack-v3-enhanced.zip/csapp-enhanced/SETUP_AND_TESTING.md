# 🚀 Quick Start & Testing Guide

## Installation & Setup

### Prerequisites
- Node.js (v16+)
- npm or yarn

### Step 1: Start the Backend

```bash
cd backend
npm install
npm start
# Server will run on http://localhost:5000
```

You should see:
```
✅ CommunityHub backend running on http://localhost:5000
   Demo Admin Credentials:
   - police / police123
   - fire / fire123
   - ambulance / ambulance123
   - plumbing / plumbing123
   - electrical / electrical123
   - cleaning / cleaning123
   - pest-control / pest123
   - admin / admin123 (Super-admin - all services)
```

### Step 2: Start the Frontend

```bash
cd frontend
npm install
npm run dev
# Frontend will run on http://localhost:5173 (or similar)
```

### Step 3: Access the Application

- **Main Page**: http://localhost:5173/
- **Admin Login**: http://localhost:5173/admin

---

## 🧪 Testing Scenarios

### Scenario 1: Submit a Service Request

1. Go to http://localhost:5173/
2. Browse available services or search
3. Click on any service card
4. Fill in the form:
   - Customer Name: "John Doe"
   - Phone: "+1-555-1234"
   - Address: "123 Main Street"
   - Details: "Need emergency response"
5. Click "Submit Request"
6. You should see a success notification

### Scenario 2: Police Admin Dashboard

1. Go to http://localhost:5173/admin
2. Find "Police" in the services grid or toggle "Show demo credentials"
3. Click the Police service or manually enter:
   - Username: `police`
   - Password: `police123`
4. Click "Sign In"
5. You'll be redirected to `/admin/dashboard/police`

**Verify these appear:**
- Header with "Police Dashboard"
- Statistics cards (Total, Pending, Attended, Resolved)
- Activity chart (last 7 days)
- Status distribution pie chart
- Request table with submitted requests

### Scenario 3: Update Request Status

From the Police dashboard:

1. Locate the request you submitted earlier
2. If status is "pending", click **"Attend"** button
3. Request status should change to "attended" (see badge update)
4. Click **"Resolve"** button
5. Request status changes to "resolved" (green badge)
6. Buttons disappear as request is completed

### Scenario 4: Test Different Services

Repeat Scenario 2 with different credentials:

**Fire Service Admin:**
- Username: `fire` | Password: `fire123`
- Path: `/admin/dashboard/fire`

**Ambulance Admin:**
- Username: `ambulance` | Password: `ambulance123`
- Path: `/admin/dashboard/ambulance`

**Electrical Service:**
- Username: `electrical` | Password: `electrical123`
- Path: `/admin/dashboard/electrical`

**Note**: Each admin only sees requests for their own service. Try submitting requests for different services and logging in as different admins to verify isolation.

### Scenario 5: Super Admin Overview

1. Go to http://localhost:5173/admin
2. Enter credentials:
   - Username: `admin`
   - Password: `admin123`
3. Click "Sign In"
4. You're redirected to `/admin/dashboard/overview`

**Verify:**
- "CommunityHub Admin Overview" title with 👑 icon
- Global stats showing totals across ALL services
- Service cards for all 7 services
- Each card shows metrics (total, pending, attended, resolved)
- Completion rate progress bars
- Comparison table at bottom
- Can click any service card to view its individual dashboard

### Scenario 6: Real-time Updates

1. Have two browser windows open:
   - Window A: Police admin logged in
   - Window B: Main page (for submitting requests)

2. In Window B:
   - Submit a new police request
   - Watch Window A - new request appears within 5 seconds (auto-refresh)

3. In Window A:
   - Click "Attend" on the new request
   - Status changes immediately
   - Chart updates after next refresh cycle

### Scenario 7: Filter by Status

From any service dashboard:

1. Look for tabs: "Pending", "Attended", "Resolved", "All"
2. Click "Pending" tab
3. Table shows only pending requests
4. Click "Attended" tab
5. Table shows only attended requests
6. Click "All" tab
7. Table shows all requests

### Scenario 8: Responsive Design

Test on different screen sizes:

```bash
# Desktop (1920x1080)
# Tablet (768x1024)
# Mobile (375x667)
```

**Check:**
- Mobile: Grid converts to single column
- All buttons are still clickable
- Table scrolls horizontally on small screens
- Navigation is accessible

---

## ✅ Verification Checklist

### Backend Verification

- [ ] Server starts without errors
- [ ] DB file created at `backend/db.json`
- [ ] All 8 demo credentials work
- [ ] Requests are stored in database
- [ ] Stats calculations are correct

### Frontend Verification

- [ ] Main page loads and shows services
- [ ] Service request form submits successfully
- [ ] Login page displays all services
- [ ] Dashboard loads after successful login
- [ ] Statistics update in real-time
- [ ] Charts render correctly
- [ ] Request table shows all data
- [ ] Status buttons work (Attend/Resolve)

### Authorization Verification

- [ ] Police admin can't access other services' requests
- [ ] Service request properly filtered by category
- [ ] Super admin can see all requests
- [ ] Super admin can navigate to any service dashboard
- [ ] Logout clears tokens properly
- [ ] Expired/invalid token redirects to login

### Data Verification

- [ ] Requests show correct customer info
- [ ] Timestamps are accurate
- [ ] Status updates persist (refresh page)
- [ ] Charts update with new data
- [ ] Statistics calculations are correct

---

## 🔍 Testing with cURL

### Test Login
```bash
curl -X POST http://localhost:5000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"username":"police","password":"police123"}'
```

Expected response:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "role": "police"
}
```

### Test Get Requests
```bash
# Copy the token from login response
TOKEN="your-jwt-token-here"

curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/admin/requests
```

### Test Get Stats
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/admin/stats
```

### Test Submit Request
```bash
curl -X POST http://localhost:5000/api/requests \
  -H "Content-Type: application/json" \
  -d '{
    "providerId": "1",
    "customerName": "John Doe",
    "customerPhone": "+1-555-1234",
    "customerAddress": "123 Main St",
    "details": "Emergency police needed"
  }'
```

### Test Update Status
```bash
REQ_ID="req_1234567_abc12"  # From the request response

curl -X PATCH http://localhost:5000/api/admin/requests/$REQ_ID \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status":"resolved"}'
```

---

## 📊 Data Structure Examples

### Sample Request Object
```json
{
  "id": "req_1713974400000_a1b2c",
  "providerId": "1",
  "providerName": "City Police Station",
  "category": "police",
  "customerName": "John Doe",
  "customerPhone": "+1-555-1234",
  "customerAddress": "123 Main Street",
  "details": "Stolen vehicle - License ABC123",
  "status": "pending",
  "createdAt": "2024-04-25T10:30:00.000Z",
  "attendedAt": null,
  "resolvedAt": null
}
```

### Sample Stats Response
```json
{
  "total": 15,
  "pending": 3,
  "attended": 7,
  "resolved": 5,
  "perDay": [
    {
      "date": "04-19",
      "received": 2,
      "attended": 1
    },
    {
      "date": "04-20",
      "received": 3,
      "attended": 2
    },
    ...
  ]
}
```

---

## 🐛 Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| CORS Error | Frontend/backend mismatch | Check both running on correct ports |
| DB file not created | Server didn't start properly | Check Node version and dependencies |
| Login fails | Wrong credentials | Verify capitalization (case-sensitive) |
| No requests visible | Request was for different service | Try logging in as that service's admin |
| Charts not showing | Browser cache | Hard refresh (Ctrl+Shift+R or Cmd+Shift+R) |
| Auto-refresh not working | Network issue | Check console for errors |

---

## 📈 Performance Tips

### For Best Experience:
1. Use Chrome or Firefox (latest versions)
2. Keep browser developer tools closed
3. Clear browser cache if seeing old data
4. Use localhost instead of IP addresses
5. Ensure stable internet connection

### Load Testing:
To test with many requests:
```bash
# Use a script to submit multiple requests
for i in {1..100}; do
  curl -X POST http://localhost:5000/api/requests \
    -H "Content-Type: application/json" \
    -d "{
      \"providerId\": \"$((RANDOM % 10 + 1))\",
      \"customerName\": \"Customer $i\",
      \"customerPhone\": \"+1-555-$((1000 + i))\",
      \"customerAddress\": \"Address $i\",
      \"details\": \"Request $i\"
    }"
done
```

---

## 🎓 Learning Resources

### Related Topics:
- React Router: https://reactrouter.com/
- JWT Authentication: https://jwt.io/
- REST API Design: https://restfulapi.net/
- Express.js: https://expressjs.com/
- Recharts: https://recharts.org/

---

## 📞 Support

For issues or questions:
1. Check the main `DASHBOARD_FEATURES.md` for detailed documentation
2. Review API endpoints in this guide
3. Check browser console for error messages
4. Verify backend logs for server-side issues

---

**Happy Testing! 🎉**
