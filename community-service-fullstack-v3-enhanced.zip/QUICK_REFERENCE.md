# 🎯 Quick Reference Guide - CommunityHub Dashboard v3.0

## 🚀 Quick Start (2 minutes)

### Step 1: Start Backend
```bash
cd csapp-enhanced/backend
npm install && npm start
# Server runs on http://localhost:5000
```

### Step 2: Start Frontend
```bash
cd csapp-enhanced/frontend
npm install && npm run dev
# Frontend on http://localhost:5173
```

### Step 3: Login
- Go to http://localhost:5173/admin
- Use any demo credentials below
- Click auto-fill or enter manually

---

## 🔑 Demo Credentials

### Service Admins
| Service | Username | Password | Dashboard |
|---------|----------|----------|-----------|
| 🚔 Police | police | police123 | `/admin/dashboard/police` |
| 🚒 Fire | fire | fire123 | `/admin/dashboard/fire` |
| 🚑 Ambulance | ambulance | ambulance123 | `/admin/dashboard/ambulance` |
| 🔧 Plumbing | plumbing | plumbing123 | `/admin/dashboard/plumbing` |
| ⚡ Electrical | electrical | electrical123 | `/admin/dashboard/electrical` |
| 🧹 Cleaning | cleaning | cleaning123 | `/admin/dashboard/cleaning` |
| 🐛 Pest Control | pest-control | pest123 | `/admin/dashboard/pest-control` |

### Super Admin
| Role | Username | Password | Dashboard |
|------|----------|----------|-----------|
| 👑 Super Admin | admin | admin123 | `/admin/dashboard/overview` |

---

## 🗺️ Navigation Map

```
http://localhost:5173/
├── / (Home - Submit requests)
├── /admin (Login page)
├── /admin/old (Original login - kept for backward compatibility)
├── /admin/dashboard/overview (Super admin view)
└── /admin/dashboard/:category (Service dashboards)
    ├── /admin/dashboard/police
    ├── /admin/dashboard/fire
    ├── /admin/dashboard/ambulance
    ├── /admin/dashboard/plumbing
    ├── /admin/dashboard/electrical
    ├── /admin/dashboard/cleaning
    └── /admin/dashboard/pest-control
```

---

## 📊 Dashboard Components

### Service Dashboard Layout
```
┌─────────────────────────────────────────┐
│  Header (Service Name + Logout)         │
├─────────────────────────────────────────┤
│  📊 Stats Cards (Total, Pending, etc)   │
├─────────────────────────────────────────┤
│  📈 Charts (Activity & Status)          │
├─────────────────────────────────────────┤
│  🔘 Status Filter Buttons               │
├─────────────────────────────────────────┤
│  📋 Request Table                       │
│  ├─ Citizen Name                        │
│  ├─ Phone (clickable)                   │
│  ├─ Address                             │
│  ├─ Details                             │
│  ├─ Submitted Time                      │
│  ├─ Status Badge                        │
│  └─ Actions (Attend/Resolve)            │
├─────────────────────────────────────────┤
│  📈 Performance Metrics Cards           │
└─────────────────────────────────────────┘
```

### Super Admin Overview Layout
```
┌─────────────────────────────────────────┐
│  Header (👑 Admin Overview)             │
├─────────────────────────────────────────┤
│  🌍 Global Stats (All Services)         │
├─────────────────────────────────────────┤
│  📱 Service Cards Grid (7 services)     │
│  ├─ Icon + Name                         │
│  ├─ Stats (Total, Pending, etc)        │
│  ├─ Completion Rate Bar                 │
│  └─ Click to View Dashboard             │
├─────────────────────────────────────────┤
│  📊 Comparison Table (All Services)     │
│  ├─ Total Requests                      │
│  ├─ Pending Count                       │
│  ├─ Attended Count                      │
│  ├─ Resolved Count                      │
│  └─ Completion %                        │
└─────────────────────────────────────────┘
```

---

## 🔐 Authorization Rules

### Who can see what?

| User | Can Access | Cannot Access |
|------|-----------|---------------|
| Police Admin | Police requests only | Fire, Ambulance, etc |
| Fire Admin | Fire requests only | Police, Ambulance, etc |
| Service Admin | Their service only | Other services |
| Super Admin | **ALL requests** | *(None)* |

**Example**: If you log in as "police", you'll only see police service requests. You cannot see fire or ambulance requests.

---

## 📋 Request Workflow

### Status Flow
```
┌─────────┐
│ PENDING │ (Initial state)
└────┬────┘
     │
     ├──→ Click "Attend" Button ──→ ┌──────────┐
     │                              │ ATTENDED │
     │                              └────┬─────┘
     │                                   │
     └──→ Click "Resolve" Button ───────┬───→ ┌──────────┐
                                        │     │ RESOLVED │
                                        └────→└──────────┘
                                               (Final)
```

### Actions Available
| Current Status | Available Buttons |
|---|---|
| Pending | "Attend" (optional) + "Resolve" |
| Attended | "Resolve" only |
| Resolved | *(none)* - Request completed |

---

## 📊 Key Metrics Explained

### Total Requests
- Sum of all requests received for this service
- Includes: Pending + Attended + Resolved

### Pending Requests
- Requests awaiting response
- Service should prioritize these
- ⚠️ Shows urgency indicator

### Attended Requests
- Staff has responded and is working
- Request is in progress
- Not yet completed

### Resolved Requests
- Completed and closed requests
- Customer issue resolved

### Completion Rate
```
Formula: (Resolved / Total) × 100%
Example: 5 resolved / 10 total = 50%
```

### Average Response Time
- Estimated based on attended requests
- Shows service efficiency
- Typical range: 15-30 minutes

---

## 📈 Charts Explained

### Activity Chart (Bar Chart)
**Shows**: Last 7 days of activity
**X-Axis**: Dates (MM-DD format)
**Y-Axis**: Request count
**Two bars per date**:
- 🔵 **Received**: New requests submitted
- 🟢 **Attended**: Requests being handled

**What to look for**:
- Peak request times
- Response efficiency (attended vs received)
- Trends over time

### Status Distribution (Pie Chart)
**Shows**: Breakdown of all requests by status
**Segments**:
- 🟠 **Pending** (Amber) - Needs attention
- 🟣 **Attended** (Purple) - In progress
- 🟢 **Resolved** (Green) - Completed

**What to look for**:
- If too many pending → Need more resources
- High resolved % → Good performance
- Large attended count → Team is busy

---

## 🔄 Real-time Updates

### Auto-refresh Intervals
| Dashboard | Interval | Purpose |
|-----------|----------|---------|
| Service Dashboard | 5 seconds | See new requests immediately |
| Super Admin Overview | 10 seconds | Monitor all services |
| Request Table | 5 seconds | Latest status updates |

### Manual Refresh
- Browser back/forward
- Click logo (if clickable)
- Press F5 or Ctrl+R

---

## 🎨 Status Badge Colors

| Status | Color | Icon | Meaning |
|--------|-------|------|---------|
| Pending | 🔴 Red | Alert | Needs immediate attention |
| Attended | 🟣 Purple | In Progress | Team is working on it |
| Resolved | 🟢 Green | Check | Completed successfully |

---

## ☎️ Quick Actions

### Contact Customer
- Click on phone number in "Contact" column
- Opens default call app
- Pre-fills the number

### View Address
- Shows in "Address" column with map icon
- Full address visible on hover

### Check Submission Time
- Shows in "Submitted" column
- Format: "Mon DD, HH:MM"
- Local timezone

---

## 🔍 Filtering Guide

### By Status Tabs
```
Top of Request Table
┌──────────┬──────────┬──────────┬────┐
│ Pending  │ Attended │ Resolved │ All│
│  Count   │  Count   │  Count   │Cnt │
└──────────┴──────────┴──────────┴────┘
```

**Usage**:
- Click "Pending" to see only pending requests
- Click "Attended" to see in-progress requests
- Click "Resolved" to see completed requests
- Click "All" to see everything

### By Service (Super Admin)
- Click any service card on overview
- Navigates to that service's dashboard

---

## 💡 Pro Tips

1. **Submit Test Requests**: Go to home page and submit requests to see them in dashboard
2. **Auto-fill Credentials**: Click service buttons on login page for quick entry
3. **Use Tabs**: Keep login tab open, dashboard in another tab
4. **Monitor Pending**: Focus on reducing pending requests count
5. **Check Trends**: View activity chart to understand busy times
6. **Track Performance**: Monitor completion rate percentage
7. **Mobile Friendly**: Dashboards work on phones too
8. **Logout Safe**: Always logout when done with session

---

## 🐛 Quick Fixes

### Issue: No requests showing
**Fix**: 
1. Make sure you submitted requests from home page
2. Check you're logged in as correct service
3. Refresh page (F5)

### Issue: Can't access service
**Fix**:
1. Only your assigned service visible
2. Use super-admin account to see all services
3. Credentials are case-sensitive

### Issue: Session expired
**Fix**:
1. Logout and login again
2. Clear browser cookies/cache
3. Check internet connection

### Issue: Charts not showing
**Fix**:
1. Hard refresh: Ctrl+Shift+R
2. Clear browser cache
3. Wait for data to load (spinning icon)

---

## 📞 Getting Help

### Check Documentation
1. **Setup Guide**: `SETUP_AND_TESTING.md`
2. **Features Guide**: `DASHBOARD_FEATURES.md`
3. **This Guide**: You're reading it!

### Debug Information
- Open browser console (F12)
- Check for error messages
- Network tab shows API calls
- Application tab shows localStorage

### Testing Steps
1. Start both servers (backend + frontend)
2. Go to home page, submit request
3. Login with admin credentials
4. Check if request appears in dashboard
5. Try changing status

---

## 📱 Mobile Experience

### Responsive Breakpoints
- **Mobile** (< 768px): Single column layout
- **Tablet** (768-1024px): 2 column layout
- **Desktop** (> 1024px): Full 4 column layout

### Touch-friendly
- Large buttons and tap targets
- Swipe to scroll tables
- Long press for menu options

---

## 🎓 Learning Resources

### Concepts to Understand
- JWT Authentication: How logins work
- Role-Based Access Control: Permission system
- Real-time Updates: Auto-refresh mechanism
- Status Workflow: Request lifecycle
- Charts & Graphs: Data visualization

### Tools Used
- React: Frontend framework
- Express: Backend framework
- Recharts: Charting library
- Tailwind CSS: Styling

---

## 📊 Sample Numbers

### Typical Dashboard Numbers
```
Total Requests: 15-50
Pending: 2-5 (should be low)
Attended: 1-3 (varies)
Resolved: 8-40 (should be high)
Completion Rate: 50-90%
Average Response: 15-30 min
```

### Performance Indicators
```
✅ Good Performance
- Pending < 5
- Completion Rate > 70%
- Average Response < 30 min

⚠️ Needs Improvement
- Pending > 10
- Completion Rate < 50%
- Average Response > 60 min
```

---

## 🔗 Useful Links

**Endpoints for Testing**:
- API Health: http://localhost:5000/api/health
- Get Providers: http://localhost:5000/api/providers
- Get Categories: http://localhost:5000/api/categories

**Frontend Pages**:
- Home: http://localhost:5173/
- Login: http://localhost:5173/admin
- Police: http://localhost:5173/admin/dashboard/police
- Super Admin: http://localhost:5173/admin/dashboard/overview

---

## 🎉 Summary

| What | Where | Who | When |
|------|-------|-----|------|
| Submit Requests | Home Page | Citizens | Anytime |
| View Requests | Service Dashboard | Service Admin | Logged in |
| Manage Requests | Service Dashboard | Service Admin | Logged in |
| Monitor All Services | Super Admin Overview | Super Admin | Logged in |
| Update Status | Service Dashboard | Service Admin | Logged in |

---

**Version**: 3.0  
**Last Updated**: April 2024  
**Status**: ✅ Ready to Use

**Happy Dashboard Management! 🚀**
