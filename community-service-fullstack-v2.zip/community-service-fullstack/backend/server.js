import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory data store
let serviceProviders = [
  {
    id: 1,
    name: "City Police Department",
    category: "Police",
    phone: "100",
    agentName: "Officer Rajesh Kumar",
    agentPhone: "+91 98765 43210",
    address: "123 Main Street, City Center",
    rating: 4.8,
    responseTime: "5-10 min",
    available: true,
    emergency: true
  },
  {
    id: 2,
    name: "Fire Station No. 1",
    category: "Fire",
    phone: "101",
    agentName: "Chief Fire Officer Arun Singh",
    agentPhone: "+91 98765 43211",
    address: "456 Fire Brigade Road",
    rating: 4.9,
    responseTime: "3-7 min",
    available: true,
    emergency: true
  },
  {
    id: 3,
    name: "City General Hospital Ambulance",
    category: "Ambulance",
    phone: "108",
    agentName: "Dr. Priya Sharma",
    agentPhone: "+91 98765 43212",
    address: "789 Hospital Avenue",
    rating: 4.7,
    responseTime: "8-12 min",
    available: true,
    emergency: true
  },
  {
    id: 4,
    name: "QuickFix Plumbing",
    category: "Plumber",
    phone: "+91 98765 43213",
    agentName: "Ramesh Patel",
    agentPhone: "+91 98765 43213",
    address: "42 Pipe Street, Industrial Area",
    rating: 4.5,
    responseTime: "30-45 min",
    available: true,
    emergency: false
  },
  {
    id: 5,
    name: "PowerUp Electricals",
    category: "Electrician",
    phone: "+91 98765 43214",
    agentName: "Suresh Gupta",
    agentPhone: "+91 98765 43214",
    address: "88 Voltage Road, Tech Park",
    rating: 4.6,
    responseTime: "20-40 min",
    available: true,
    emergency: false
  },
  {
    id: 6,
    name: "Swift Rescue Team",
    category: "Ambulance",
    phone: "+91 98765 43215",
    agentName: "Paramedic Anita Desai",
    agentPhone: "+91 98765 43215",
    address: "55 Emergency Lane",
    rating: 4.4,
    responseTime: "10-15 min",
    available: true,
    emergency: true
  },
  {
    id: 7,
    name: "PipeMaster Pro",
    category: "Plumber",
    phone: "+91 98765 43216",
    agentName: "Vikram Malhotra",
    agentPhone: "+91 98765 43216",
    address: "77 Drain Road, Westside",
    rating: 4.3,
    responseTime: "25-50 min",
    available: true,
    emergency: false
  },
  {
    id: 8,
    name: "ElectroCare Solutions",
    category: "Electrician",
    phone: "+91 98765 43217",
    agentName: "Amit Verma",
    agentPhone: "+91 98765 43217",
    address: "33 Circuit Street, Eastside",
    rating: 4.7,
    responseTime: "15-35 min",
    available: true,
    emergency: false
  },
  {
    id: 9,
    name: "Green Valley Police",
    category: "Police",
    phone: "+91 98765 43218",
    agentName: "Inspector Meena Reddy",
    agentPhone: "+91 98765 43218",
    address: "22 Law & Order Road, Green Valley",
    rating: 4.6,
    responseTime: "6-12 min",
    available: true,
    emergency: true
  },
  {
    id: 10,
    name: "Rapid Fire Response",
    category: "Fire",
    phone: "+91 98765 43219",
    agentName: "Deputy Chief Karthik Nair",
    agentPhone: "+91 98765 43219",
    address: "99 Safety Boulevard, Northside",
    rating: 4.8,
    responseTime: "4-8 min",
    available: true,
    emergency: true
  }
];

let serviceRequests = [];

// Get all categories
app.get('/api/categories', (req, res) => {
  const categories = [...new Set(serviceProviders.map(p => p.category))];
  res.json(categories);
});

// Get all providers (with optional search/filter)
app.get('/api/providers', (req, res) => {
  const { search, category } = req.query;
  let filtered = [...serviceProviders];
  
  if (search) {
    const searchLower = search.toLowerCase();
    filtered = filtered.filter(p => 
      p.name.toLowerCase().includes(searchLower) ||
      p.category.toLowerCase().includes(searchLower) ||
      p.agentName.toLowerCase().includes(searchLower)
    );
  }
  
  if (category && category !== 'All') {
    filtered = filtered.filter(p => p.category === category);
  }
  
  res.json(filtered);
});

// Get provider by ID
app.get('/api/providers/:id', (req, res) => {
  const provider = serviceProviders.find(p => p.id === parseInt(req.params.id));
  if (!provider) {
    return res.status(404).json({ message: 'Provider not found' });
  }
  res.json(provider);
});

// Create service request
app.post('/api/requests', (req, res) => {
  const { providerId, customerName, customerPhone, customerAddress, issueDetails } = req.body;
  
  if (!customerName || !customerPhone) {
    return res.status(400).json({ message: 'Name and phone are required' });
  }
  
  const provider = serviceProviders.find(p => p.id === parseInt(providerId));
  if (!provider) {
    return res.status(404).json({ message: 'Provider not found' });
  }
  
  const request = {
    id: serviceRequests.length + 1,
    providerId: parseInt(providerId),
    providerName: provider.name,
    agentName: provider.agentName,
    agentPhone: provider.agentPhone,
    customerName,
    customerPhone,
    customerAddress: customerAddress || '',
    issueDetails: issueDetails || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  
  serviceRequests.push(request);
  res.status(201).json(request);
});

// Get all service requests
app.get('/api/requests', (req, res) => {
  res.json(serviceRequests);
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
