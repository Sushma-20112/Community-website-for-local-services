# Community Service Full-Stack Application

A complete full-stack application connecting users with local service providers (Police, Fire, Ambulance, Plumbers, Electricians).

## Project Structure

```
community-service-fullstack/
├── backend/          # Node.js + Express API
│   ├── package.json
│   └── server.js     # Main server file
├── frontend/         # React + Vite + TypeScript + Tailwind
│   ├── package.json
│   ├── vite.config.ts
│   └── src/          # React components, pages, hooks
└── README.md
```

## Backend Technologies

- **Runtime**: Node.js
- **Framework**: Express.js
- **Middleware**: CORS for cross-origin requests
- **Data Storage**: In-memory (can be upgraded to MongoDB/PostgreSQL)
- **API Type**: RESTful JSON API

### Backend API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/categories | Get all service categories |
| GET | /api/providers | Get all providers (with search & filter) |
| GET | /api/providers/:id | Get provider by ID |
| POST | /api/requests | Create new service request |
| GET | /api/requests | Get all service requests |
| GET | /api/health | Health check |

### Backend Data Model

**ServiceProvider:**
```javascript
{
  id: number,
  name: string,           // Company/Service name
  category: string,       // Police, Fire, Ambulance, Plumber, Electrician
  phone: string,          // Main contact number
  agentName: string,      // Person/agent name
  agentPhone: string,     // Agent's direct phone
  address: string,
  rating: number,
  responseTime: string,
  available: boolean,
  emergency: boolean
}
```

**ServiceRequest:**
```javascript
{
  id: number,
  providerId: number,
  providerName: string,
  agentName: string,
  agentPhone: string,
  customerName: string,   // Customer who requested
  customerPhone: string,  // Customer's phone
  customerAddress: string,
  issueDetails: string,
  status: string,
  createdAt: string
}
```

## Frontend Technologies

- **Framework**: React 18
- **Build Tool**: Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui (Radix UI primitives)
- **Icons**: Lucide React
- **Notifications**: Sonner (toast messages)
- **HTTP Client**: Fetch API
- **Routing**: React Router DOM

### Frontend Components

| Component | Purpose |
|-----------|---------|
| HeroSection | Landing hero with search & emergency buttons |
| ServiceCard | Display provider info with ratings & contact |
| CategoryFilter | Filter services by category |
| RequestModal | Form to request service (captures customer details) |
| Footer | App footer with links |

## How to Run

### 1. Start the Backend

```bash
cd backend
npm install
npm run dev
```

Backend runs on: **http://localhost:5000**

### 2. Start the Frontend (New Terminal)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on: **http://localhost:5173**

### 3. Open Browser

Navigate to: **http://localhost:5173**

## Features

✅ Search providers by name, category, or agent
✅ Filter by category (Police, Fire, Ambulance, Plumber, Electrician)
✅ Emergency quick-call buttons (112, 100, 101)
✅ Request service form (captures customer name, phone, address, issue)
✅ Provider ratings and response time display
✅ Agent/Partner details visible on cards
✅ Toast notifications for user feedback
✅ Mobile-responsive design

## Sample Data Included

The backend comes with 10 pre-loaded providers:
- 2 Police stations
- 2 Fire stations
- 2 Ambulance services
- 2 Plumbers
- 2 Electricians

Each includes agent name and phone number for direct contact.

## Next Steps for Production

1. **Add Database**: Replace in-memory with MongoDB or PostgreSQL
2. **Authentication**: Add JWT-based user login/signup
3. **Admin Panel**: Dashboard to manage providers and requests
4. **Real-time Updates**: WebSocket for live status updates
5. **SMS Integration**: Send SMS to agents when requests come in
6. **Geolocation**: Add maps for finding nearest providers
