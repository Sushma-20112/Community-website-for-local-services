import { Phone, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const HeroSection = ({ searchQuery, onSearchChange }: HeroSectionProps) => {
  return (
    <section className="relative overflow-hidden bg-gradient-hero py-20 px-4 text-primary-foreground">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(255,255,255,0.1),transparent_60%)]" />
      <div className="relative max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary-foreground/15 backdrop-blur-sm text-sm font-medium mb-6">
          <Phone className="w-4 h-4" />
          Emergency & Community Services
        </div>
        <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight mb-4">
          Your Community,<br />One Tap Away
        </h1>
        <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto mb-8">
          Instantly connect with plumbers, electricians, fire services, ambulance, police and more — all in one place.
        </p>
        <div className="relative max-w-xl mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search services, providers..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-12 pr-4 py-4 rounded-2xl bg-card text-card-foreground shadow-service-hover text-base outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="flex flex-wrap gap-3 justify-center mt-6">
          <Button
            variant="outline"
            className="bg-primary-foreground/15 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/25 backdrop-blur-sm"
            onClick={() => window.open("tel:112")}
          >
            <Phone className="w-4 h-4 mr-2" /> Call 112
          </Button>
          <Button
            variant="outline"
            className="bg-primary-foreground/15 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/25 backdrop-blur-sm"
            onClick={() => window.open("tel:100")}
          >
            🚔 Police — 100
          </Button>
          <Button
            variant="outline"
            className="bg-primary-foreground/15 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/25 backdrop-blur-sm"
            onClick={() => window.open("tel:101")}
          >
            🚒 Fire — 101
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
