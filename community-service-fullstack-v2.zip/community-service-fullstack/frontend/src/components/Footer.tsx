import { Phone } from "lucide-react";

const Footer = () => (
  <footer className="bg-foreground text-background py-10 px-4 mt-12">
    <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
      <div>
        <h3 className="font-display text-lg font-bold mb-2 flex items-center gap-2">
          <Phone className="w-5 h-5" /> CommunityHub
        </h3>
        <p className="text-sm opacity-70">Your one-stop emergency and utility service platform.</p>
      </div>
      <div>
        <h4 className="font-semibold mb-2">Emergency Numbers</h4>
        <ul className="space-y-1 text-sm opacity-70">
          <li>Police — 100</li>
          <li>Fire — 101</li>
          <li>Ambulance — 102</li>
          <li>Universal — 112</li>
        </ul>
      </div>
      <div>
        <h4 className="font-semibold mb-2">Service Partners</h4>
        <p className="text-sm opacity-70">
          Interested in listing your service? Contact us at <span className="underline">partners@communityhub.app</span>
        </p>
      </div>
    </div>
    <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-background/20 text-center text-xs opacity-50">
      © 2026 CommunityHub. All rights reserved.
    </div>
  </footer>
);

export default Footer;
