import { useState } from "react";
import { ServiceProvider } from "@/data/services";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";

interface RequestModalProps {
  provider: ServiceProvider | null;
  open: boolean;
  onClose: () => void;
}

const RequestModal = ({ provider, open, onClose }: RequestModalProps) => {
  const [form, setForm] = useState({ name: "", phone: "", address: "", details: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) {
      toast({ title: "Please fill in your name and phone number", variant: "destructive" });
      return;
    }
    toast({
      title: "Request Sent! ✅",
      description: `${provider?.name} will contact you at ${form.phone} shortly.`,
    });
    setForm({ name: "", phone: "", address: "", details: "" });
    onClose();
  };

  if (!provider) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Request Service</DialogTitle>
          <DialogDescription>
            Contact <strong>{provider.name}</strong> — provide your details and they'll reach out.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Your Name</Label>
            <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="John Doe" />
          </div>
          <div>
            <Label htmlFor="phone">Your Phone Number</Label>
            <Input id="phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 555-0000" />
          </div>
          <div>
            <Label htmlFor="address">Your Address</Label>
            <Input id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="123 Main St" />
          </div>
          <div>
            <Label htmlFor="details">Issue Details</Label>
            <Textarea id="details" value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} placeholder="Describe your issue..." rows={3} />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="submit" className="flex-1">Send Request</Button>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default RequestModal;
