import { Phone, MapPin, Clock, Star } from "lucide-react";
import { ServiceProvider, categories } from "@/data/services";
import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  provider: ServiceProvider;
  onContact: (provider: ServiceProvider) => void;
}

const ServiceCard = ({ provider, onContact }: ServiceCardProps) => {
  const cat = categories.find((c) => c.id === provider.category);

  return (
    <div className="group bg-card rounded-2xl border border-border p-5 shadow-service hover:shadow-service-hover transition-all duration-300 hover:-translate-y-1">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{cat?.icon}</span>
          <div>
            <h3 className="font-display font-bold text-card-foreground">{provider.name}</h3>
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
              {cat?.label}
            </span>
          </div>
        </div>
        <span
          className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
            provider.available
              ? "bg-service-green/15 text-service-green"
              : "bg-muted text-muted-foreground"
          }`}
        >
          {provider.available ? "Available" : "Offline"}
        </span>
      </div>

      <p className="text-sm text-muted-foreground mb-4">{provider.description}</p>

      <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
        <div className="flex items-center gap-2">
          <Phone className="w-3.5 h-3.5" />
          <span className="font-medium text-card-foreground">{provider.phone}</span>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="w-3.5 h-3.5" />
          {provider.address}
        </div>
        <div className="flex items-center gap-2">
          <Clock className="w-3.5 h-3.5" />
          Response: {provider.responseTime}
        </div>
        <div className="flex items-center gap-1">
          <Star className="w-3.5 h-3.5 fill-service-amber text-service-amber" />
          <span className="font-medium text-card-foreground">{provider.rating}</span>
        </div>
      </div>

      <div className="flex gap-2">
        <Button
          className="flex-1"
          onClick={() => window.open(`tel:${provider.phone}`)}
        >
          <Phone className="w-4 h-4 mr-2" /> Call Now
        </Button>
        <Button variant="outline" className="flex-1" onClick={() => onContact(provider)}>
          Request Service
        </Button>
      </div>
    </div>
  );
};

export default ServiceCard;
