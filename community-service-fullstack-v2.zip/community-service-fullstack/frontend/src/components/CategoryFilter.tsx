import { categories, ServiceCategory } from "@/data/services";

interface CategoryFilterProps {
  selected: ServiceCategory | "all";
  onSelect: (cat: ServiceCategory | "all") => void;
}

const CategoryFilter = ({ selected, onSelect }: CategoryFilterProps) => {
  return (
    <section className="py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="font-display text-2xl font-bold mb-4">Browse by Category</h2>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => onSelect("all")}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
              selected === "all"
                ? "bg-foreground text-background shadow-service"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            All Services
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelect(cat.id)}
              className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center gap-2 ${
                selected === cat.id
                  ? "bg-foreground text-background shadow-service"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              }`}
            >
              <span>{cat.icon}</span>
              {cat.label}
              {cat.emergency && (
                <span className="w-2 h-2 rounded-full bg-emergency animate-pulse" />
              )}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryFilter;
