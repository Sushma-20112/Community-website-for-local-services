export interface ServiceProvider {
  id: string;
  name: string;
  category: ServiceCategory;
  phone: string;
  address: string;
  rating: number;
  available: boolean;
  description: string;
  responseTime: string;
}

export type ServiceCategory =
  | "emergency"
  | "plumbing"
  | "electrical"
  | "fire"
  | "ambulance"
  | "police"
  | "cleaning"
  | "pest-control";

export interface CategoryInfo {
  id: ServiceCategory;
  label: string;
  icon: string;
  color: string;
  emergency: boolean;
}

export const categories: CategoryInfo[] = [
  { id: "police", label: "Police", icon: "🚔", color: "bg-service-blue", emergency: true },
  { id: "fire", label: "Fire Service", icon: "🚒", color: "bg-emergency", emergency: true },
  { id: "ambulance", label: "Ambulance", icon: "🚑", color: "bg-service-green", emergency: true },
  { id: "plumbing", label: "Plumber", icon: "🔧", color: "bg-service-amber", emergency: false },
  { id: "electrical", label: "Electrician", icon: "⚡", color: "bg-service-purple", emergency: false },
  { id: "cleaning", label: "Cleaning", icon: "🧹", color: "bg-service-green", emergency: false },
  { id: "pest-control", label: "Pest Control", icon: "🐛", color: "bg-service-amber", emergency: false },
  { id: "emergency", label: "General Emergency", icon: "🆘", color: "bg-emergency", emergency: true },
];

export const providers: ServiceProvider[] = [
  { id: "1", name: "City Police Station", category: "police", phone: "100", address: "Main Road, Downtown", rating: 4.5, available: true, description: "24/7 law enforcement and emergency response", responseTime: "5 min" },
  { id: "2", name: "Central Fire Station", category: "fire", phone: "101", address: "Fire Lane, Sector 12", rating: 4.8, available: true, description: "Fire rescue and prevention services", responseTime: "7 min" },
  { id: "3", name: "City Hospital Ambulance", category: "ambulance", phone: "102", address: "Hospital Road, Medical Hub", rating: 4.7, available: true, description: "Emergency medical transport and first aid", responseTime: "8 min" },
  { id: "4", name: "QuickFix Plumbing", category: "plumbing", phone: "+1 555-0101", address: "12 Workshop Lane", rating: 4.3, available: true, description: "Pipe repair, installation & emergency leak fixing", responseTime: "30 min" },
  { id: "5", name: "PowerLine Electricians", category: "electrical", phone: "+1 555-0202", address: "45 Circuit Ave", rating: 4.6, available: true, description: "Wiring, panel upgrades & emergency power restoration", responseTime: "25 min" },
  { id: "6", name: "SparkSafe Electrical", category: "electrical", phone: "+1 555-0203", address: "78 Voltage St", rating: 4.2, available: false, description: "Licensed electrical inspections and repairs", responseTime: "45 min" },
  { id: "7", name: "DrainMaster Plumbing", category: "plumbing", phone: "+1 555-0104", address: "33 Pipe Road", rating: 4.0, available: true, description: "Drain cleaning, water heater service", responseTime: "40 min" },
  { id: "8", name: "CleanSweep Services", category: "cleaning", phone: "+1 555-0301", address: "9 Fresh Blvd", rating: 4.4, available: true, description: "Home and office deep cleaning services", responseTime: "1 hr" },
  { id: "9", name: "BugAway Pest Control", category: "pest-control", phone: "+1 555-0401", address: "21 Shield Lane", rating: 4.1, available: true, description: "Termite, rodent & insect extermination", responseTime: "2 hrs" },
  { id: "10", name: "Emergency Helpline", category: "emergency", phone: "112", address: "Citywide Coverage", rating: 4.9, available: true, description: "Universal emergency dispatch center", responseTime: "3 min" },
];
