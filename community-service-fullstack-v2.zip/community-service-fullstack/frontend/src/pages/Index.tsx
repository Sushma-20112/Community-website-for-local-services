import { useState, useMemo } from "react";
import HeroSection from "@/components/HeroSection";
import CategoryFilter from "@/components/CategoryFilter";
import ServiceCard from "@/components/ServiceCard";
import RequestModal from "@/components/RequestModal";
import Footer from "@/components/Footer";
import { providers, ServiceCategory, ServiceProvider } from "@/data/services";

const Index = () => {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<ServiceCategory | "all">("all");
  const [selectedProvider, setSelectedProvider] = useState<ServiceProvider | null>(null);

  const filtered = useMemo(() => {
    return providers.filter((p) => {
      const matchesCat = category === "all" || p.category === category;
      const q = search.toLowerCase();
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.category.includes(q) ||
        p.description.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });
  }, [search, category]);

  return (
    <div className="min-h-screen flex flex-col">
      <HeroSection searchQuery={search} onSearchChange={setSearch} />
      <CategoryFilter selected={category} onSelect={setCategory} />

      <section className="flex-1 px-4 pb-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display text-2xl font-bold">
              {category === "all" ? "All Providers" : `${category.charAt(0).toUpperCase() + category.slice(1)} Services`}
            </h2>
            <span className="text-sm text-muted-foreground">{filtered.length} found</span>
          </div>
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <p className="text-4xl mb-3">🔍</p>
              <p className="font-medium">No providers found. Try a different search or category.</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map((p) => (
                <ServiceCard key={p.id} provider={p} onContact={setSelectedProvider} />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />

      <RequestModal
        provider={selectedProvider}
        open={!!selectedProvider}
        onClose={() => setSelectedProvider(null)}
      />
    </div>
  );
};

export default Index;
